﻿var animationLoading = bodymovin.loadAnimation({
    container: document.getElementById('loader'),
    renderer: 'svg',
    loop: true,
    autoplay: true,
    path: 'jsonanimated/splashscreen/loader.json'
})