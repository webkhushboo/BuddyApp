var db = null;

document.addEventListener('deviceready', function() {
  db = window.sqlitePlugin.openDatabase({
    name: 'my.db',
    location: 'default',
  });
});

function download(img,page_id,column_name,table_name) {
    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fs) {

        var url = "http://res.cloudinary.com/buddy-industries-cc/image/upload/c_fill,h_900,w_1600/"+img+".jpg";
        var random_string = Math.floor(Math.random() * 1012534);
        fs.root.getFile(img+random_string+'.jpg', {
            create: true,
            exclusive: false
        }, function (fileEntry) {
            file_transfer(fileEntry, encodeURI(url), true,page_id,column_name,table_name);

        }, onErrorCreateFile);

    }, onErrorLoadFs);
}

function onErrorLoadFs(msg){
    alert(msg);
}

function onErrorCreateFile(msg){
    alert(msg);
}

function file_transfer(fileEntry, uri, readBinaryData,page_id,column_name,table_name) {

    var fileTransfer = new FileTransfer();
    var fileURL = fileEntry.toURL();
     //alert(fileURL)
    fileTransfer.download(
        uri,
        fileURL,
        function (entry) {
           /* alert("download complete: " + entry.toURL());
                        alert(page_id);
                        alert(user_id);
                        alert(column_name);
                        alert(table_name);   */
             db.transaction(function (tx) {
              tx.executeSql('update '+table_name+' set '+column_name+' = ? where page_id = ? and user_id = ?', [entry.toURL(),page_id,user.id]); 
              if(column_name == 'image_name_thumb')
              {
              
                alert('Download is completed');
                
              }      
          });  
              //entry.toURL();
            if (readBinaryData) {
                // Read the file...
               // readBinaryFile(entry);
            } else {
                // Or just display it.
               // displayImageByFileURL(entry);
            }

        },
        function (error) {
            alert("download error source " + error.source);
            alert("download error target " + error.target);
            alert("upload error code" + error.code);
        },
        null, // or, pass false
        {
            //headers: {
            //    "Authorization": "Basic dGVzdHVzZXJuYW1lOnRlc3RwYXNzd29yZA=="
            //}
        }
    );
}

function downloadpageoffline(id)
{
   jQuery(document).ready(function($)
   {
     
      $.ajax({
                    type: "GET",
                    url: 'http://buddy.na/api/getbuddypages/'+id,
                    dataType:'json',                    
                    success: function (data) {
                       var JSONObject = JSON.stringify(data);
                       
                      // var JSONObject = JSONObject.stringify(data);
                      //var db = openDatabase('mydb', '1.0', 'Test DB', 2 * 1024 * 1024);
                      
                     db.transaction(function (tx) {   
   tx.executeSql('CREATE TABLE IF NOT EXISTS pages (id INTEGER AUTO_INCREMENT, page_id, user_id,location_id,longitude,latitude,virtualtour_link,contact_name,contact_position,contact_email,name,detail TEXT,postal_address,telephone,cellphone,fax,email,street_name,website,image_name,image_name_thumb,icon_image_name,gallery_limit,products_limit,link_name,small_summary)'); 
    
     
     
   /*tx.executeSql('insert into pages (page_id, user_id,location_id,longitude,latitude,virtualtour_link,contact_name,contact_position,contact_email,name,detail,postal_address,telephone,cellphone,fax,email,street_name,website,image_name,image_name_thumb,icon_image_name,gallery_limit,products_limit,link_name) values ("'+data.place.id+'","'+data.place.user_id+'","'+data.place.location_id+'","'+data.place.longitude+'","'+data.place.latitude+'","'+data.place.virtualtour_link+'","'+data.place.contact_name+'","'+data.place.contact_position+'","'+data.place.contact_email+'","'+data.place.name+'","'+data.place.detail+'","'+data.place.postal_address+'","'+data.place.telephone+'","'+data.place.cellphone+'","'+data.place.fax+'","'+data.place.email+'","'+data.place.street_name+'","'+data.place.website+'","'+data.place.image_name+'","'+data.place.image_name_thumb+'","'+data.place.icon_image_name+'","'+data.place.gallery_limit+'","'+data.place.products_limit+'","'+data.place.link_name+'")'); */
}, function(error) {
   // alert('Table already created ' + error.message);
  }, function() {
    //alert('Table created OK');
  });  
  
  db.transaction(function (tx) {   
     
      tx.executeSql('delete from pages where page_id = ? and user_id = ?', [data.place.id,user.id]);
      tx.executeSql('SELECT * FROM pages where page_id = ? and user_id = ?', [data.place.id,user.id], function (tx, results) { 
           var len = results.rows.length, i;
           
           //alert(len)
           if(len === 0 || len === '0')
           {
               // alert('inserting');
              var executeQuery = "insert into pages (page_id, user_id,location_id,longitude,latitude,virtualtour_link,contact_name,contact_position,contact_email,name,detail,postal_address,telephone,cellphone,fax,email,street_name,website,image_name,image_name_thumb,icon_image_name,gallery_limit,products_limit,link_name,small_summary) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                //alert(user.id)
                //tx.executeSql('alter table pages add column small_summary');
                //alert(data.place.user_id);
                tx.executeSql(executeQuery, [data.place.id, user.id,data.place.location_id,data.place.longitude,data.place.latitude,data.place.virtualtour_link,data.place.contact_name,data.place.contact_position,data.place.contact_email,data.place.name,data.place.detail,data.place.postal_address,data.place.telephone,data.place.cellphone,data.place.fax,data.place.email,data.place.street_name,data.place.website,data.place.image_name,data.place.image_name_thumb,data.place.icon_image_name,data.place.gallery_limit,data.place.products_limit,data.place.link_name,data.place.small_summary]
      , function(tx, result) {
      var column_name = 'image_name';
      var table_name = 'pages';
     
      download(data.place.image_name,data.place.id,column_name,table_name);
      
      
      var column_name = 'image_name_thumb';
    download(data.place.image_name_thumb,data.place.id,column_name,table_name);
      
          
      
            //alert('Inserted');
      },
      function(error){
          //alert('Error occurred');
      }
      
      );
           }
     });  
     
  });
   db.transaction(function (tx) { 
   tx.executeSql('SELECT * FROM pages where page_id = ? and user_id = ?', [data.place.id,user.id], function (tx, results) { 
      var len = results.rows.length, i; 
      msg = "<p>Found rows: " + len + "</p>"; 
      //alert(msg)
     // document.querySelector('#status').innerHTML +=  msg; 
  
      for (i = 0; i < len; i++) { 
       //  alert(results.rows.item(i).image_name );
         //alert(results.rows.item(i).detail ); 
      } 
  
   }, null); 
});
                        
   /* $('.get_apn_invt').html('');
    for (var key in JSONObject) {
     if (JSONObject.hasOwnProperty(key)) {
     //alert(JSONObject[key]["name"] + ", " + JSONObject[key]["image"]);
      var ats = '<div class="apn_sct"> <div class="invot_img"> <img class="on_inv_image" src=img/'+ JSONObject[key]["image"] +' </div> <div class="invot_nme"> '+ JSONObject[key]["name"] +' </div>  </div>';
      //alert(ats);
      $('.get_apn_invt').append(ats);
     }
    }    */

    // alert(json.array_results); 
    // $('#gt_invt').append('array_results');
                    }
                    
                    });
     //alert(id) 
   });
   
}